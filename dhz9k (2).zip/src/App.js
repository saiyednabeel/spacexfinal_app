import React from "react";
import "./styles.css";
import Spacexlaunchprogram from "./Spacex_launch_program";
export default function App() {
  return (
    <div className="App">
      <h2>SPACEX LAUNCH PROGRAM</h2>
      <Spacexlaunchprogram /> {/*Main Component */}
      <h2>
        {" "}
        Developed By <span>Saiyed Nabeel</span>
      </h2>
    </div>
  );
}
