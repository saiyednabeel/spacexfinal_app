import React from "react";

function Single_Card(props) {
  var data = props.data;
  var image = data.links.mission_patch;
  var landing = data.rocket.first_stage.cores[0].land_success;

  const renderKeys = () => {
    // to render all the id from mission id list
    return data.mission_id.map((val) => {
      return <li>{val}</li>;
    });
  };
  return (
    <div className="card">
      <img src={image} alt="launch_image" />
      <h1 className="name_no">
        {data.mission_name} #{data.flight_number}
      </h1>
      <h1>Mission ids:-</h1>
      <ul>{renderKeys()}</ul>
      <h1>
        launch year <span>{data.launch_year}</span>
      </h1>
      <h1>
        launch :-<span>{data.launch_success ? "sucess" : "fail"}</span>
      </h1>
      <h1>
        landing :- <span>{landing ? "sucess" : "fail"}</span>
      </h1>
    </div>
  );
}

export default Single_Card;
